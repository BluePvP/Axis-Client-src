/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel.group;

import io.netty.channel.group.ChannelGroupFuture;
import io.netty.util.concurrent.GenericFutureListener;

public interface ChannelGroupFutureListener
extends GenericFutureListener<ChannelGroupFuture> {
}

