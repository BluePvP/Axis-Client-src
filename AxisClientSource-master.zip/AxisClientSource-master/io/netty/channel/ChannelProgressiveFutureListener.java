/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel;

import io.netty.channel.ChannelProgressiveFuture;
import io.netty.util.concurrent.GenericProgressiveFutureListener;

public interface ChannelProgressiveFutureListener
extends GenericProgressiveFutureListener<ChannelProgressiveFuture> {
}

