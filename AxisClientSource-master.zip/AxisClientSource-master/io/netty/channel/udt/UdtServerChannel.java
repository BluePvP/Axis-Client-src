/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel.udt;

import io.netty.channel.ServerChannel;
import io.netty.channel.udt.UdtChannel;

public interface UdtServerChannel
extends ServerChannel,
UdtChannel {
}

