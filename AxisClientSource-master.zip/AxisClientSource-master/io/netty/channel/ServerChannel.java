/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel;

import io.netty.channel.Channel;

public interface ServerChannel
extends Channel {
}

