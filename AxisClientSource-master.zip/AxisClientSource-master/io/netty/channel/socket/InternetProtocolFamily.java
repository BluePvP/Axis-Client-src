/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel.socket;

public enum InternetProtocolFamily {
    IPv4,
    IPv6;

}

