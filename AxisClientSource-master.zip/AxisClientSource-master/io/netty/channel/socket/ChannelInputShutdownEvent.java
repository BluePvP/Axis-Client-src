/*
 * Decompiled with CFR 0.150.
 */
package io.netty.channel.socket;

public final class ChannelInputShutdownEvent {
    public static final ChannelInputShutdownEvent INSTANCE = new ChannelInputShutdownEvent();

    private ChannelInputShutdownEvent() {
    }
}

