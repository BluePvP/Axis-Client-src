/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.codec.http.websocketx;

import io.netty.channel.ChannelInboundHandler;

public interface WebSocketFrameDecoder
extends ChannelInboundHandler {
}

