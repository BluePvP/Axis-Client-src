/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.codec.http.websocketx;

import io.netty.handler.codec.http.websocketx.WebSocket08FrameEncoder;

public class WebSocket13FrameEncoder
extends WebSocket08FrameEncoder {
    public WebSocket13FrameEncoder(boolean maskPayload) {
        super(maskPayload);
    }
}

