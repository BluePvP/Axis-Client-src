/*
 * Decompiled with CFR 0.150.
 */
package com.sun.jna;

public interface AltCallingConvention {
}

