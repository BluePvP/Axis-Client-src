/*
 * Decompiled with CFR 0.150.
 */
package com.sun.jna;

import com.sun.jna.NativeLibrary;
import java.lang.reflect.Method;

public interface FunctionMapper {
    public String getFunctionName(NativeLibrary var1, Method var2);
}

