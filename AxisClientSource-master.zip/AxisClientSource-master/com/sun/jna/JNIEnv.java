/*
 * Decompiled with CFR 0.150.
 */
package com.sun.jna;

public final class JNIEnv {
    public static final JNIEnv CURRENT = new JNIEnv();

    private JNIEnv() {
    }
}

