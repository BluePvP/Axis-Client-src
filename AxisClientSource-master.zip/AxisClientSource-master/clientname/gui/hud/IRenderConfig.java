/*
 * Decompiled with CFR 0.150.
 */
package clientname.gui.hud;

import clientname.gui.hud.ScreenPosition;

public interface IRenderConfig {
    public void save(ScreenPosition var1);

    public ScreenPosition load();
}

