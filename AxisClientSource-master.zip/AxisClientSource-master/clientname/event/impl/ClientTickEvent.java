/*
 * Decompiled with CFR 0.150.
 */
package clientname.event.impl;

import clientname.event.Event;

public class ClientTickEvent
extends Event {
}

